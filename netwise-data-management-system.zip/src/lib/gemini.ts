import { distributeUsage, type DistributedApp } from "./mockData";

export type AnalysisResult = {
  summary: string;
  source: "gemini" | "fallback";
  apps: DistributedApp[];
};

type GeminiApp = {
  appName?: string;
  category?: string;
  estimatedGb?: number;
  percentage?: number;
  detail?: string;
  tip?: string;
};

// يستدعي Gemini API لتحليل استهلاك كل تطبيق بدقة.
// المفتاح يُقرأ من process.env فقط (لا يظهر في الواجهة).
export async function analyzeWithGemini(params: {
  name: string;
  monthlyGb: number;
  usedGb: number;
  remainingDays: number;
}): Promise<AnalysisResult> {
  const { name, monthlyGb, usedGb, remainingDays } = params;
  const baseline = distributeUsage(usedGb);
  const apiKey = process.env.GEMINI_API_KEY;

  if (!apiKey) {
    return {
      source: "fallback",
      summary: `تم توزيع ${usedGb.toFixed(
        1,
      )} جيجا على تطبيقاتك بناءً على أنماط استخدام واقعية. أعلى استهلاك من تطبيقات الفيديو، ويُنصح بتفعيل وضع توفير البيانات فيها.`,
      apps: baseline,
    };
  }

  const prompt = `أنت محلل بيانات لتطبيق NetWise لإدارة استهلاك الإنترنت.
المستخدم: ${name}
الباقة الشهرية: ${monthlyGb} جيجا
المستهلك حتى الآن: ${usedGb} جيجا
الأيام المتبقية: ${remainingDays}

هذه بيانات افتراضية واقعية لتوزيع الاستهلاك على التطبيقات:
${baseline
  .map((a) => `- ${a.appName} (${a.category}): ${a.estimatedGb} جيجا (${a.percentage}%)`)
  .join("\n")}

حلّل استهلاك كل تطبيق بدقة، وأعِد النتيجة بصيغة JSON فقط بدون أي نص إضافي، وبالشكل التالي:
{
  "summary": "ملخص تحليلي قصير بالعربية عن سلوك الاستهلاك ونصيحة عامة",
  "apps": [
    { "appName": "...", "category": "...", "estimatedGb": 0.0, "percentage": 0.0, "detail": "معلومة دقيقة عن معدل استهلاك التطبيق", "tip": "نصيحة عملية لترشيد الاستهلاك" }
  ]
}
حافظ على نفس أسماء التطبيقات وقيم estimatedGb و percentage كما هي، وحسّن فقط summary و detail و tip.`;

  try {
    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: {
            temperature: 0.4,
            responseMimeType: "application/json",
          },
        }),
        // مهلة معقولة للعرض التوضيحي
        signal: AbortSignal.timeout(20000),
      },
    );

    if (!res.ok) throw new Error(`Gemini HTTP ${res.status}`);
    const data = await res.json();
    const text: string | undefined =
      data?.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!text) throw new Error("Empty Gemini response");

    const cleaned = text.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(cleaned) as {
      summary?: string;
      apps?: GeminiApp[];
    };

    const merged: DistributedApp[] = baseline.map((base) => {
      const match = parsed.apps?.find((p) => p.appName === base.appName);
      return {
        appName: base.appName,
        category: match?.category ?? base.category,
        estimatedGb: base.estimatedGb,
        percentage: base.percentage,
        detail: match?.detail ?? base.detail,
        tip: match?.tip ?? base.tip,
      };
    });

    return {
      source: "gemini",
      summary: parsed.summary ?? "تم تحليل الاستهلاك بواسطة Gemini بنجاح.",
      apps: merged,
    };
  } catch {
    return {
      source: "fallback",
      summary: `تم توزيع ${usedGb.toFixed(
        1,
      )} جيجا على تطبيقاتك بناءً على أنماط استخدام واقعية. أعلى استهلاك من تطبيقات الفيديو، ويُنصح بتفعيل وضع توفير البيانات فيها.`,
      apps: baseline,
    };
  }
}
