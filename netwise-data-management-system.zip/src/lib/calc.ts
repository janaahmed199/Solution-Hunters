// حساب الحد اليومي للاستهلاك بحيث تكفي الباقة لآخر الشهر
export function computeDailyLimit(
  monthlyGb: number,
  usedGb: number,
  remainingDays: number,
): number {
  const remainingGb = Math.max(0, monthlyGb - usedGb);
  const days = Math.max(1, remainingDays);
  return Math.round((remainingGb / days) * 100) / 100;
}
