// بيانات افتراضية واقعية تحاكي استهلاك التطبيقات لدى مستخدم حقيقي.
// الأوزان تمثل السلوك النموذجي لمستخدم عربي متوسط.

export type AppTemplate = {
  appName: string;
  category: string;
  weight: number; // الوزن النسبي في الاستهلاك
  detail: string; // معلومة عن معدل استهلاك التطبيق
  tip: string; // نصيحة لترشيد الاستهلاك
};

export const APP_TEMPLATES: AppTemplate[] = [
  {
    appName: "YouTube",
    category: "فيديو",
    weight: 26,
    detail: "مشاهدة فيديو HD تستهلك ~1.5 جيجا/ساعة، أما 480p فتستهلك ~0.5 جيجا/ساعة.",
    tip: "قلّل الجودة إلى 480p عند استخدام بيانات الهاتف لتوفير حتى 60%.",
  },
  {
    appName: "TikTok",
    category: "فيديو قصير",
    weight: 19,
    detail: "التمرير المستمر للفيديوهات يستهلك ~0.8 جيجا لكل ساعة تصفح.",
    tip: "فعّل Data Saver داخل التطبيق لتقليل جودة التحميل التلقائي.",
  },
  {
    appName: "Instagram",
    category: "تواصل اجتماعي",
    weight: 14,
    detail: "الـ Reels والقصص تستهلك ~0.7 جيجا/ساعة، والصور ~0.1 جيجا/ساعة.",
    tip: "أوقف التشغيل التلقائي للفيديو من إعدادات استخدام البيانات.",
  },
  {
    appName: "Netflix",
    category: "بث",
    weight: 12,
    detail: "الجودة العالية تستهلك ~3 جيجا/ساعة، والمتوسطة ~0.7 جيجا/ساعة.",
    tip: "حمّل الحلقات على Wi-Fi للمشاهدة لاحقًا دون بيانات.",
  },
  {
    appName: "WhatsApp",
    category: "مراسلة",
    weight: 8,
    detail: "الرسالة النصية ~5 كيلوبايت، والمكالمة الصوتية ~0.3 ميجا/دقيقة، الفيديو ~4 ميجا/دقيقة.",
    tip: "أوقف التنزيل التلقائي للوسائط عبر بيانات الهاتف.",
  },
  {
    appName: "Facebook",
    category: "تواصل اجتماعي",
    weight: 7,
    detail: "تصفح الخلاصة مع الفيديوهات يستهلك ~0.6 جيجا/ساعة.",
    tip: "استخدم وضع توفير البيانات في تطبيق فيسبوك.",
  },
  {
    appName: "Spotify",
    category: "موسيقى",
    weight: 4,
    detail: "البث بجودة عالية ~0.15 جيجا/ساعة، والعادية ~0.07 جيجا/ساعة.",
    tip: "حمّل قوائم التشغيل للاستماع دون اتصال.",
  },
  {
    appName: "Google Chrome",
    category: "تصفح",
    weight: 4,
    detail: "تصفح المواقع العادية ~0.06 جيجا/ساعة حسب المحتوى.",
    tip: "فعّل Lite Mode لضغط الصفحات وتوفير البيانات.",
  },
  {
    appName: "Snapchat",
    category: "تواصل اجتماعي",
    weight: 3,
    detail: "الرسائل المصورة والقصص تستهلك ~0.4 جيجا/ساعة.",
    tip: "أوقف Travel Mode مفعّلًا لمنع التحميل المسبق.",
  },
  {
    appName: "Zoom",
    category: "مكالمات فيديو",
    weight: 2,
    detail: "مكالمة فيديو جماعية ~0.8 جيجا/ساعة، وفردية ~0.5 جيجا/ساعة.",
    tip: "أطفئ الكاميرا عند عدم الحاجة لتقليل الاستهلاك للنصف.",
  },
  {
    appName: "Gmail",
    category: "بريد",
    weight: 1,
    detail: "استهلاك منخفض ~0.02 جيجا/يوم بدون مرفقات كبيرة.",
    tip: "حمّل المرفقات الكبيرة عبر Wi-Fi فقط.",
  },
];

export type DistributedApp = {
  appName: string;
  category: string;
  estimatedGb: number;
  percentage: number;
  detail: string;
  tip: string;
};

// توزيع إجمالي الاستهلاك على التطبيقات حسب الأوزان الواقعية
export function distributeUsage(totalUsedGb: number): DistributedApp[] {
  const safeTotal = Math.max(0, totalUsedGb);
  const weightSum = APP_TEMPLATES.reduce((s, a) => s + a.weight, 0);
  return APP_TEMPLATES.map((a) => {
    const gb = (a.weight / weightSum) * safeTotal;
    return {
      appName: a.appName,
      category: a.category,
      estimatedGb: Math.round(gb * 100) / 100,
      percentage: Math.round((a.weight / weightSum) * 1000) / 10,
      detail: a.detail,
      tip: a.tip,
    };
  });
}
