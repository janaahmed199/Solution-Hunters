export type Profile = {
  id: number;
  name: string;
  phone: string;
  monthlyGb: number;
  usedGb: number;
  remainingDays: number;
  dailyLimit: number;
  todayUsage: number;
  plan: string;
  subscriptionStart: string | null;
  blockingEnabled: boolean;
  warningCount: number;
  blockedUntil: string | null;
  createdAt: string;
  updatedAt: string;
};

export type AppUsageRow = {
  id: number;
  profileId: number;
  appName: string;
  category: string;
  estimatedGb: number;
  percentage: number;
  detail: string;
  tip: string;
};

export type AlertItem = {
  type: string;
  message: string;
  at?: number;
};
