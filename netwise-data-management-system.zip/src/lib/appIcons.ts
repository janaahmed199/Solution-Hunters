export const APP_ICONS: Record<string, string> = {
  YouTube: "▶️",
  TikTok: "🎵",
  Instagram: "📸",
  Netflix: "🎬",
  WhatsApp: "💬",
  Facebook: "👥",
  Spotify: "🎧",
  "Google Chrome": "🌐",
  Snapchat: "👻",
  Zoom: "🎥",
  Gmail: "✉️",
};

export function appIcon(name: string): string {
  return APP_ICONS[name] ?? "📱";
}
