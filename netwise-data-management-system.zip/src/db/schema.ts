import {
  boolean,
  integer,
  pgTable,
  real,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

// عملاء NetWise / Customer profiles
export const profiles = pgTable("profiles", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  phone: text("phone").notNull().unique(),
  // الباقة المدفوعة بالجيجا خلال الشهر
  monthlyGb: real("monthly_gb").notNull().default(0),
  // المستهلك بالفعل هذا الشهر
  usedGb: real("used_gb").notNull().default(0),
  // الأيام الباقية في الشهر
  remainingDays: integer("remaining_days").notNull().default(30),
  // الحد اليومي المحسوب
  dailyLimit: real("daily_limit").notNull().default(0),
  // استهلاك اليوم الحالي
  todayUsage: real("today_usage").notNull().default(0),
  // الخطة: free | paid
  plan: text("plan").notNull().default("free"),
  // بداية الاشتراك المدفوع (أول شهرين مجانًا)
  subscriptionStart: timestamp("subscription_start"),
  // تفعيل خاصية الحظر عند تجاوز الحد
  blockingEnabled: boolean("blocking_enabled").notNull().default(true),
  // عدد التنبيهات المستخدمة
  warningCount: integer("warning_count").notNull().default(0),
  // محظور حتى هذا الوقت
  blockedUntil: timestamp("blocked_until"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// تحليل استهلاك كل تطبيق (ناتج من Gemini)
export const appUsage = pgTable("app_usage", {
  id: serial("id").primaryKey(),
  profileId: integer("profile_id")
    .notNull()
    .references(() => profiles.id, { onDelete: "cascade" }),
  appName: text("app_name").notNull(),
  category: text("category").notNull(),
  // الجيجا المقدّرة لهذا التطبيق
  estimatedGb: real("estimated_gb").notNull().default(0),
  // نسبة من إجمالي الاستهلاك
  percentage: real("percentage").notNull().default(0),
  // معلومة عن معدل الاستهلاك (مثال: رسالة واتساب ~ 5KB)
  detail: text("detail").notNull().default(""),
  // نصيحة لترشيد الاستهلاك
  tip: text("tip").notNull().default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// سجل التنبيهات والإجراءات
export const alerts = pgTable("alerts", {
  id: serial("id").primaryKey(),
  profileId: integer("profile_id")
    .notNull()
    .references(() => profiles.id, { onDelete: "cascade" }),
  type: text("type").notNull(), // warning | block | info
  message: text("message").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Profile = typeof profiles.$inferSelect;
export type AppUsage = typeof appUsage.$inferSelect;
export type Alert = typeof alerts.$inferSelect;
