import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Cairo } from "next/font/google";
import "./globals.css";

const cairo = Cairo({
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "600", "700", "800"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "NetWise — إدارة استهلاك الإنترنت بذكاء",
  description:
    "NetWise: نظّم استهلاك باقة الإنترنت، احسب حدك اليومي، واحصل على تنبيهات ذكية وتحليل لكل تطبيق. Created by Jana & Sara.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body className={`${cairo.className} nw-body antialiased`}>{children}</body>
    </html>
  );
}
