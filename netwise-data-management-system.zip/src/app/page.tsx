"use client";

import { useState } from "react";
import Header from "@/components/Header";
import SetupForm, { type SetupValues } from "@/components/SetupForm";
import Dashboard from "@/components/Dashboard";
import type { Profile, AppUsageRow, AlertItem } from "@/lib/types";

export default function Home() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [apps, setApps] = useState<AppUsageRow[]>([]);
  const [summary, setSummary] = useState("");
  const [source, setSource] = useState<"gemini" | "fallback" | null>(null);
  const [alerts, setAlerts] = useState<AlertItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState(false);
  const [editing, setEditing] = useState(false);
  const [error, setError] = useState("");

  const initial: Partial<SetupValues> | undefined = profile
    ? {
        name: profile.name,
        phone: profile.phone,
        monthlyGb: String(profile.monthlyGb),
        usedGb: String(profile.usedGb),
        remainingDays: String(profile.remainingDays),
      }
    : undefined;

  async function handleSetup(v: SetupValues) {
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: v.name,
          phone: v.phone,
          monthlyGb: Number(v.monthlyGb),
          usedGb: Number(v.usedGb),
          remainingDays: Number(v.remainingDays),
          plan: profile?.plan ?? "free",
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "خطأ في الحفظ");
      setProfile(data.profile);
      setApps(data.apps);
      setSummary(data.analysis?.summary ?? "");
      setSource(data.analysis?.source ?? null);
      setAlerts([
        {
          type: "info",
          message: `تم حساب حدك اليومي: ${data.profile.dailyLimit} جيجا/يوم لتكفيك الباقة حتى نهاية الشهر.`,
        },
      ]);
      setEditing(false);
    } catch (e) {
      setError(e instanceof Error ? e.message : "حدث خطأ");
    } finally {
      setLoading(false);
    }
  }

  async function post(url: string, body: Record<string, unknown>) {
    setBusy(true);
    try {
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "خطأ");
      if (data.profile) setProfile(data.profile);
      if (Array.isArray(data.newAlerts) && data.newAlerts.length) {
        setAlerts((prev) => [
          ...data.newAlerts.map((a: AlertItem) => ({ ...a, at: Date.now() })),
          ...prev,
        ]);
      }
      return data;
    } catch (e) {
      setAlerts((prev) => [
        {
          type: "info",
          message: e instanceof Error ? e.message : "حدث خطأ",
        },
        ...prev,
      ]);
    } finally {
      setBusy(false);
    }
  }

  const pid = profile?.id;

  return (
    <main className="mx-auto max-w-6xl px-4 py-8 sm:py-12">
      <Header />

      {!profile || editing ? (
        <div className="mx-auto max-w-2xl space-y-4">
          <SetupForm
            onSubmit={handleSetup}
            loading={loading}
            initial={initial}
          />
          {error && (
            <p className="rounded-lg bg-red-50 px-3 py-2 text-center text-sm text-red-600">
              {error}
            </p>
          )}
          {editing && (
            <button
              onClick={() => setEditing(false)}
              className="nw-btn mx-auto block rounded-full border border-[var(--nw-pink-200)] bg-white px-5 py-2 text-sm font-semibold text-[var(--nw-pink-600)]"
            >
              رجوع للوحة التحكم
            </button>
          )}
        </div>
      ) : (
        <Dashboard
          profile={profile}
          apps={apps}
          summary={summary}
          source={source}
          alerts={alerts}
          busy={busy}
          onEdit={() => setEditing(true)}
          onAddUsage={(gb) => pid && post("/api/usage", { profileId: pid, addGb: gb })}
          onToggleBlocking={(enabled) =>
            pid &&
            post("/api/settings", {
              profileId: pid,
              action: "toggleBlocking",
              enabled,
            })
          }
          onUnblock={() =>
            pid && post("/api/settings", { profileId: pid, action: "unblock" })
          }
          onResetDay={() =>
            pid && post("/api/settings", { profileId: pid, action: "resetDay" })
          }
          onUpgrade={() =>
            pid &&
            post("/api/settings", { profileId: pid, action: "upgradePlan" })
          }
          onDowngrade={() =>
            pid &&
            post("/api/settings", { profileId: pid, action: "downgradePlan" })
          }
        />
      )}

      <footer className="mt-12 text-center text-xs text-[var(--nw-muted)]">
        NetWise © 2026 · Created by Jana &amp; Sara
      </footer>
    </main>
  );
}
