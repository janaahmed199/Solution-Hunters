import { db } from "@/db";
import { profiles, appUsage } from "@/db/schema";
import { eq } from "drizzle-orm";
import { computeDailyLimit } from "@/lib/calc";
import { analyzeWithGemini } from "@/lib/gemini";

export const dynamic = "force-dynamic";

// جلب ملف العميل عبر رقم التليفون
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const phone = searchParams.get("phone");
  if (!phone) {
    return Response.json({ error: "phone is required" }, { status: 400 });
  }
  const [profile] = await db
    .select()
    .from(profiles)
    .where(eq(profiles.phone, phone));
  if (!profile) {
    return Response.json({ error: "not found" }, { status: 404 });
  }
  const apps = await db
    .select()
    .from(appUsage)
    .where(eq(appUsage.profileId, profile.id));
  return Response.json({ profile, apps });
}

// إنشاء / تحديث ملف العميل مع تحليل Gemini
export async function POST(req: Request) {
  try {
    const body = await req.json();
    const name = String(body.name ?? "").trim();
    const phone = String(body.phone ?? "").trim();
    const monthlyGb = Number(body.monthlyGb);
    const usedGb = Number(body.usedGb);
    const remainingDays = parseInt(String(body.remainingDays), 10);
    const plan = body.plan === "paid" ? "paid" : "free";

    if (!name || !phone) {
      return Response.json(
        { error: "الاسم ورقم التليفون مطلوبان" },
        { status: 400 },
      );
    }
    if (
      !Number.isFinite(monthlyGb) ||
      !Number.isFinite(usedGb) ||
      !Number.isFinite(remainingDays) ||
      monthlyGb <= 0 ||
      usedGb < 0 ||
      remainingDays <= 0
    ) {
      return Response.json(
        { error: "أدخل أرقامًا صحيحة للجيجا والأيام" },
        { status: 400 },
      );
    }

    const dailyLimit = computeDailyLimit(monthlyGb, usedGb, remainingDays);

    // تحليل الاستهلاك بواسطة Gemini
    const analysis = await analyzeWithGemini({
      name,
      monthlyGb,
      usedGb,
      remainingDays,
    });

    const [existing] = await db
      .select()
      .from(profiles)
      .where(eq(profiles.phone, phone));

    let profileId: number;

    if (existing) {
      const [updated] = await db
        .update(profiles)
        .set({
          name,
          monthlyGb,
          usedGb,
          remainingDays,
          dailyLimit,
          plan,
          subscriptionStart:
            plan === "paid"
              ? existing.subscriptionStart ?? new Date()
              : existing.subscriptionStart,
          updatedAt: new Date(),
        })
        .where(eq(profiles.id, existing.id))
        .returning();
      profileId = updated.id;
    } else {
      const [created] = await db
        .insert(profiles)
        .values({
          name,
          phone,
          monthlyGb,
          usedGb,
          remainingDays,
          dailyLimit,
          plan,
          subscriptionStart: plan === "paid" ? new Date() : null,
        })
        .returning();
      profileId = created.id;
    }

    // إعادة كتابة تحليل التطبيقات
    await db.delete(appUsage).where(eq(appUsage.profileId, profileId));
    if (analysis.apps.length) {
      await db.insert(appUsage).values(
        analysis.apps.map((a) => ({
          profileId,
          appName: a.appName,
          category: a.category,
          estimatedGb: a.estimatedGb,
          percentage: a.percentage,
          detail: a.detail,
          tip: a.tip,
        })),
      );
    }

    const [profile] = await db
      .select()
      .from(profiles)
      .where(eq(profiles.id, profileId));
    const apps = await db
      .select()
      .from(appUsage)
      .where(eq(appUsage.profileId, profileId));

    return Response.json({
      profile,
      apps,
      analysis: { summary: analysis.summary, source: analysis.source },
    });
  } catch (err) {
    return Response.json(
      { error: err instanceof Error ? err.message : "server error" },
      { status: 500 },
    );
  }
}
