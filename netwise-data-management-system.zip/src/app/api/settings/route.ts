import { db } from "@/db";
import { profiles, alerts } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

// إجراءات التحكم في البيانات والإعدادات
export async function POST(req: Request) {
  try {
    const body = await req.json();
    const profileId = Number(body.profileId);
    const action = String(body.action ?? "");

    if (!Number.isFinite(profileId) || !action) {
      return Response.json({ error: "بيانات غير صحيحة" }, { status: 400 });
    }

    const [profile] = await db
      .select()
      .from(profiles)
      .where(eq(profiles.id, profileId));
    if (!profile) {
      return Response.json({ error: "not found" }, { status: 404 });
    }

    const now = new Date();
    const updates: Partial<typeof profile> = { updatedAt: now };
    let alertMessage: { type: string; message: string } | null = null;

    switch (action) {
      case "toggleBlocking": {
        const enabled = Boolean(body.enabled);
        updates.blockingEnabled = enabled;
        if (!enabled) {
          updates.blockedUntil = null; // إلغاء الحظر عند التعطيل
          updates.warningCount = 0;
        }
        alertMessage = {
          type: "info",
          message: enabled
            ? "تم تفعيل خاصية الحظر عند تجاوز الحد اليومي."
            : "تم تعطيل خاصية الحظر (وضع الطوارئ). سيبقى الإنترنت مفتوحًا.",
        };
        break;
      }
      case "unblock": {
        updates.blockedUntil = null;
        updates.warningCount = 0;
        alertMessage = {
          type: "info",
          message: "تم إلغاء الحظر يدويًا (وضع الطوارئ). الإنترنت متاح الآن.",
        };
        break;
      }
      case "resetDay": {
        updates.todayUsage = 0;
        updates.warningCount = 0;
        updates.blockedUntil = null;
        alertMessage = {
          type: "info",
          message: "تم بدء يوم جديد. أُعيد ضبط استهلاك اليوم.",
        };
        break;
      }
      case "upgradePlan": {
        updates.plan = "paid";
        updates.subscriptionStart = profile.subscriptionStart ?? now;
        alertMessage = {
          type: "info",
          message: "تم تفعيل الخطة المدفوعة — أول شهرين مجانًا! 🎉",
        };
        break;
      }
      case "downgradePlan": {
        updates.plan = "free";
        alertMessage = {
          type: "info",
          message: "تم التحويل إلى الخطة المجانية.",
        };
        break;
      }
      default:
        return Response.json({ error: "إجراء غير معروف" }, { status: 400 });
    }

    const [updated] = await db
      .update(profiles)
      .set(updates)
      .where(eq(profiles.id, profileId))
      .returning();

    if (alertMessage) {
      await db.insert(alerts).values({
        profileId,
        type: alertMessage.type,
        message: alertMessage.message,
      });
    }

    return Response.json({ profile: updated, newAlerts: alertMessage ? [alertMessage] : [] });
  } catch (err) {
    return Response.json(
      { error: err instanceof Error ? err.message : "server error" },
      { status: 500 },
    );
  }
}
