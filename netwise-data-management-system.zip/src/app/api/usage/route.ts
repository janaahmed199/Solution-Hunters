import { db } from "@/db";
import { profiles, alerts } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

const HOUR_MS = 60 * 60 * 1000;
const MAX_WARNINGS = 2; // تنبيهان قبل الحظر

// إضافة استهلاك اليوم ومتابعة الحد اليومي
export async function POST(req: Request) {
  try {
    const body = await req.json();
    const profileId = Number(body.profileId);
    const addGb = Number(body.addGb);

    if (!Number.isFinite(profileId) || !Number.isFinite(addGb) || addGb <= 0) {
      return Response.json({ error: "بيانات غير صحيحة" }, { status: 400 });
    }

    const [profile] = await db
      .select()
      .from(profiles)
      .where(eq(profiles.id, profileId));
    if (!profile) {
      return Response.json({ error: "not found" }, { status: 404 });
    }

    const now = new Date();

    // التحقق من الحظر الحالي
    if (
      profile.blockingEnabled &&
      profile.blockedUntil &&
      profile.blockedUntil > now
    ) {
      return Response.json({
        profile,
        blocked: true,
        newAlerts: [
          {
            type: "block",
            message: `الإنترنت محظور مؤقتًا حتى ${profile.blockedUntil.toLocaleTimeString(
              "ar-EG",
            )}. يمكنك إلغاء الحظر من الإعدادات في حالات الطوارئ.`,
          },
        ],
      });
    }

    const newTodayUsage = Math.round((profile.todayUsage + addGb) * 100) / 100;
    const newUsedGb = Math.round((profile.usedGb + addGb) * 100) / 100;

    const newAlerts: { type: string; message: string }[] = [];
    let warningCount = profile.warningCount;
    let blockedUntil: Date | null = profile.blockedUntil;

    const reachedLimit = newTodayUsage >= profile.dailyLimit;

    if (reachedLimit) {
      warningCount += 1;

      if (!profile.blockingEnabled) {
        // وضع الطوارئ: الحظر معطّل
        newAlerts.push({
          type: "info",
          message:
            "تجاوزت الحد اليومي، لكن خاصية الحظر معطّلة (وضع الطوارئ). انتبه فقد لا تكفي الباقة لآخر الشهر.",
        });
      } else if (warningCount <= MAX_WARNINGS) {
        const remaining = MAX_WARNINGS - warningCount + 1;
        newAlerts.push({
          type: "warning",
          message: `تنبيه: وصلت للحد اليومي (${profile.dailyLimit} جيجا). لديك ${remaining} ${
            remaining === 1 ? "تنبيه" : "تنبيهات"
          } قبل حظر الإنترنت لمدة ساعة.`,
        });
      } else {
        // تجاوز عدد التنبيهات → حظر لمدة ساعة
        blockedUntil = new Date(now.getTime() + HOUR_MS);
        warningCount = 0;
        newAlerts.push({
          type: "block",
          message: `تم حظر الإنترنت لمدة ساعة لحمايتك من استنفاد الباقة. ينتهي الحظر ${blockedUntil.toLocaleTimeString(
            "ar-EG",
          )}. يمكنك إلغاؤه من الإعدادات في الطوارئ.`,
        });
      }
    }

    const [updated] = await db
      .update(profiles)
      .set({
        todayUsage: newTodayUsage,
        usedGb: newUsedGb,
        warningCount,
        blockedUntil,
        updatedAt: now,
      })
      .where(eq(profiles.id, profileId))
      .returning();

    if (newAlerts.length) {
      await db.insert(alerts).values(
        newAlerts.map((a) => ({
          profileId,
          type: a.type,
          message: a.message,
        })),
      );
    }

    return Response.json({
      profile: updated,
      blocked: Boolean(
        updated.blockingEnabled &&
          updated.blockedUntil &&
          updated.blockedUntil > now,
      ),
      newAlerts,
    });
  } catch (err) {
    return Response.json(
      { error: err instanceof Error ? err.message : "server error" },
      { status: 500 },
    );
  }
}
