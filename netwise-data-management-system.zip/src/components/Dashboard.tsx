"use client";

import { useEffect, useMemo, useState } from "react";
import type { Profile, AppUsageRow, AlertItem } from "@/lib/types";
import { appIcon } from "@/lib/appIcons";

type Props = {
  profile: Profile;
  apps: AppUsageRow[];
  summary: string;
  source: "gemini" | "fallback" | null;
  alerts: AlertItem[];
  busy: boolean;
  onAddUsage: (gb: number) => void;
  onToggleBlocking: (enabled: boolean) => void;
  onUnblock: () => void;
  onResetDay: () => void;
  onUpgrade: () => void;
  onDowngrade: () => void;
  onEdit: () => void;
};

function StatCard({
  label,
  value,
  unit,
  icon,
  accent,
}: {
  label: string;
  value: string;
  unit?: string;
  icon: string;
  accent?: boolean;
}) {
  return (
    <div
      className={`nw-card p-4 ${
        accent ? "ring-2 ring-[var(--nw-pink-300)]" : ""
      }`}
    >
      <div className="mb-2 flex items-center justify-between">
        <span className="text-xs font-semibold text-[var(--nw-muted)]">
          {label}
        </span>
        <span className="text-lg">{icon}</span>
      </div>
      <div className="text-2xl font-extrabold text-[var(--nw-pink-700)]">
        {value}
        {unit && (
          <span className="mr-1 text-sm font-medium text-[var(--nw-muted)]">
            {unit}
          </span>
        )}
      </div>
    </div>
  );
}

function useCountdown(target: string | null) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    if (!target) return;
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, [target]);
  if (!target) return null;
  const diff = new Date(target).getTime() - now;
  if (diff <= 0) return null;
  const m = Math.floor(diff / 60000);
  const s = Math.floor((diff % 60000) / 1000);
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export default function Dashboard({
  profile,
  apps,
  summary,
  source,
  alerts,
  busy,
  onAddUsage,
  onToggleBlocking,
  onUnblock,
  onResetDay,
  onUpgrade,
  onDowngrade,
  onEdit,
}: Props) {
  const countdown = useCountdown(
    profile.blockingEnabled ? profile.blockedUntil : null,
  );
  const isBlocked = Boolean(countdown);

  const remainingGb = Math.max(0, profile.monthlyGb - profile.usedGb);
  const usedPct = Math.min(
    100,
    (profile.usedGb / Math.max(profile.monthlyGb, 0.01)) * 100,
  );
  const todayPct = Math.min(
    100,
    (profile.todayUsage / Math.max(profile.dailyLimit, 0.01)) * 100,
  );
  const overLimit = profile.todayUsage >= profile.dailyLimit;

  const maxApp = useMemo(
    () => Math.max(0.01, ...apps.map((a) => a.estimatedGb)),
    [apps],
  );

  const [customGb, setCustomGb] = useState("0.5");

  return (
    <div className="space-y-6">
      {/* ترحيب + تعديل */}
      <div className="nw-card flex flex-col items-start justify-between gap-3 p-5 sm:flex-row sm:items-center">
        <div>
          <p className="text-sm text-[var(--nw-muted)]">مرحبًا</p>
          <p className="text-lg font-bold text-[var(--nw-pink-700)]">
            {profile.name}{" "}
            <span className="text-sm font-normal text-[var(--nw-muted)]">
              ({profile.phone})
            </span>
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span
            className={`rounded-full px-3 py-1 text-xs font-bold ${
              profile.plan === "paid"
                ? "nw-gradient text-white"
                : "bg-[var(--nw-pink-100)] text-[var(--nw-pink-700)]"
            }`}
          >
            {profile.plan === "paid" ? "الخطة المدفوعة ✨" : "الخطة المجانية"}
          </span>
          <button
            onClick={onEdit}
            className="nw-btn rounded-full border border-[var(--nw-pink-200)] bg-white px-4 py-1.5 text-xs font-semibold text-[var(--nw-pink-600)]"
          >
            تعديل البيانات
          </button>
        </div>
      </div>

      {/* بطاقات الإحصائيات */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard
          label="باقة الشهر"
          value={profile.monthlyGb.toFixed(1)}
          unit="جيجا"
          icon="📦"
        />
        <StatCard
          label="المتبقي"
          value={remainingGb.toFixed(1)}
          unit="جيجا"
          icon="🔋"
        />
        <StatCard
          label="الأيام الباقية"
          value={String(profile.remainingDays)}
          unit="يوم"
          icon="🗓️"
        />
        <StatCard
          label="الحد اليومي"
          value={profile.dailyLimit.toFixed(2)}
          unit="جيجا/يوم"
          icon="🎯"
          accent
        />
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* استهلاك اليوم والتحكم */}
        <div className="nw-card space-y-5 p-6 lg:col-span-2">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-[var(--nw-pink-700)]">
              متابعة استهلاك اليوم
            </h3>
            {isBlocked ? (
              <span className="rounded-full bg-red-100 px-3 py-1 text-xs font-bold text-red-600">
                🔒 محظور — {countdown}
              </span>
            ) : overLimit ? (
              <span className="rounded-full bg-amber-100 px-3 py-1 text-xs font-bold text-amber-700">
                ⚠️ تجاوزت الحد اليومي
              </span>
            ) : (
              <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-bold text-emerald-700">
                ✅ ضمن الحد
              </span>
            )}
          </div>

          {/* شريط اليوم */}
          <div>
            <div className="mb-1 flex justify-between text-sm">
              <span className="font-semibold">
                {profile.todayUsage.toFixed(2)} / {profile.dailyLimit.toFixed(2)}{" "}
                جيجا اليوم
              </span>
              <span className="text-[var(--nw-muted)]">
                {todayPct.toFixed(0)}%
              </span>
            </div>
            <div className="nw-track h-3">
              <div
                className={`h-full rounded-full transition-all ${
                  overLimit ? "bg-red-400" : "nw-gradient"
                }`}
                style={{ width: `${todayPct}%` }}
              />
            </div>
          </div>

          {/* شريط الشهر */}
          <div>
            <div className="mb-1 flex justify-between text-sm">
              <span className="font-semibold">
                إجمالي الشهر: {profile.usedGb.toFixed(1)} /{" "}
                {profile.monthlyGb.toFixed(1)} جيجا
              </span>
              <span className="text-[var(--nw-muted)]">
                {usedPct.toFixed(0)}%
              </span>
            </div>
            <div className="nw-track h-3">
              <div
                className="h-full rounded-full bg-[var(--nw-pink-400)] transition-all"
                style={{ width: `${usedPct}%` }}
              />
            </div>
          </div>

          {isBlocked && (
            <div className="rounded-xl bg-red-50 p-4 text-sm text-red-700">
              <p className="font-bold">🔒 الإنترنت محظور مؤقتًا ({countdown})</p>
              <p className="mt-1">
                في حالة الطوارئ يمكنك إلغاء الحظر فورًا من الإعدادات بالأسفل.
              </p>
              <button
                onClick={onUnblock}
                disabled={busy}
                className="nw-btn mt-3 rounded-lg bg-red-500 px-4 py-2 text-xs font-bold text-white"
              >
                إلغاء الحظر (طوارئ)
              </button>
            </div>
          )}

          {/* إجراءات التحكم في البيانات */}
          <div>
            <p className="mb-2 text-sm font-bold text-[var(--nw-pink-700)]">
              محاكاة الاستهلاك (Data Control)
            </p>
            <div className="flex flex-wrap items-center gap-2">
              {[0.1, 0.25, 0.5, 1].map((g) => (
                <button
                  key={g}
                  onClick={() => onAddUsage(g)}
                  disabled={busy || isBlocked}
                  className="nw-btn rounded-lg border border-[var(--nw-pink-200)] bg-white px-3 py-2 text-sm font-semibold text-[var(--nw-pink-600)] disabled:opacity-50"
                >
                  +{g} جيجا
                </button>
              ))}
              <div className="flex items-center gap-1">
                <input
                  className="nw-input !w-24 !py-2"
                  type="number"
                  min={0.01}
                  step="0.1"
                  value={customGb}
                  onChange={(e) => setCustomGb(e.target.value)}
                />
                <button
                  onClick={() => onAddUsage(Number(customGb))}
                  disabled={busy || isBlocked || Number(customGb) <= 0}
                  className="nw-btn nw-gradient rounded-lg px-3 py-2 text-sm font-bold text-white disabled:opacity-50"
                >
                  استهلك
                </button>
              </div>
              <button
                onClick={onResetDay}
                disabled={busy}
                className="nw-btn rounded-lg bg-[var(--nw-pink-100)] px-3 py-2 text-sm font-semibold text-[var(--nw-pink-700)]"
              >
                🔄 يوم جديد
              </button>
            </div>
          </div>
        </div>

        {/* التنبيهات الذكية */}
        <div className="nw-card flex flex-col p-6">
          <h3 className="mb-3 text-lg font-bold text-[var(--nw-pink-700)]">
            التنبيهات الذكية
          </h3>
          <div className="nw-scroll flex-1 space-y-2 overflow-y-auto pl-1"
            style={{ maxHeight: 320 }}
          >
            {alerts.length === 0 ? (
              <p className="text-sm text-[var(--nw-muted)]">
                لا توجد تنبيهات بعد. استمر في المتابعة وسيصلك تنبيه عند الاقتراب
                من الحد اليومي.
              </p>
            ) : (
              alerts.map((a, i) => {
                const color =
                  a.type === "block"
                    ? "bg-red-50 text-red-700 border-red-200"
                    : a.type === "warning"
                      ? "bg-amber-50 text-amber-800 border-amber-200"
                      : "bg-[var(--nw-pink-50)] text-[var(--nw-pink-700)] border-[var(--nw-pink-200)]";
                const icon =
                  a.type === "block" ? "🔒" : a.type === "warning" ? "⚠️" : "ℹ️";
                return (
                  <div
                    key={i}
                    className={`nw-pop rounded-xl border p-3 text-sm ${color}`}
                  >
                    <span className="ml-1">{icon}</span>
                    {a.message}
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* تحليل التطبيقات بواسطة Gemini */}
      <div className="nw-card p-6">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          <h3 className="text-lg font-bold text-[var(--nw-pink-700)]">
            تحليل استهلاك التطبيقات
          </h3>
          <span
            className={`rounded-full px-3 py-1 text-xs font-bold ${
              source === "gemini"
                ? "bg-emerald-100 text-emerald-700"
                : "bg-[var(--nw-pink-100)] text-[var(--nw-pink-700)]"
            }`}
          >
            {source === "gemini"
              ? "🤖 تحليل Gemini AI"
              : "🤖 تحليل تقديري ذكي"}
          </span>
        </div>

        {summary && (
          <p className="mb-5 rounded-xl bg-[var(--nw-pink-50)] p-4 text-sm leading-6 text-[var(--nw-ink)]">
            {summary}
          </p>
        )}

        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {apps.map((a) => (
            <div
              key={a.id}
              className="rounded-xl border border-[var(--nw-pink-100)] bg-white/70 p-4"
            >
              <div className="mb-2 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xl">{appIcon(a.appName)}</span>
                  <div>
                    <p className="font-bold">{a.appName}</p>
                    <p className="text-xs text-[var(--nw-muted)]">
                      {a.category}
                    </p>
                  </div>
                </div>
                <div className="text-left">
                  <p className="font-extrabold text-[var(--nw-pink-700)]">
                    {a.estimatedGb.toFixed(2)} جيجا
                  </p>
                  <p className="text-xs text-[var(--nw-muted)]">
                    {a.percentage}%
                  </p>
                </div>
              </div>
              <div className="nw-track mb-2 h-2">
                <div
                  className="nw-gradient h-full rounded-full"
                  style={{ width: `${(a.estimatedGb / maxApp) * 100}%` }}
                />
              </div>
              <p className="text-xs leading-5 text-[var(--nw-ink)]">
                {a.detail}
              </p>
              <p className="mt-1 text-xs font-semibold text-[var(--nw-pink-600)]">
                💡 {a.tip}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* الإعدادات */}
      <div className="nw-card p-6">
        <h3 className="mb-4 text-lg font-bold text-[var(--nw-pink-700)]">
          الإعدادات والتحكم
        </h3>
        <div className="flex flex-col items-start justify-between gap-3 rounded-xl border border-[var(--nw-pink-100)] bg-white/70 p-4 sm:flex-row sm:items-center">
          <div>
            <p className="font-bold">حظر الإنترنت عند تجاوز الحد اليومي</p>
            <p className="text-sm text-[var(--nw-muted)]">
              بعد تنبيهين يتم حظر الإنترنت ساعة لحماية باقتك. يمكنك تعطيلها في
              الطوارئ.
            </p>
          </div>
          <button
            onClick={() => onToggleBlocking(!profile.blockingEnabled)}
            disabled={busy}
            className={`nw-btn relative h-8 w-16 rounded-full transition-colors ${
              profile.blockingEnabled
                ? "nw-gradient"
                : "bg-[var(--nw-pink-200)]"
            }`}
            aria-pressed={profile.blockingEnabled}
          >
            <span
              className={`absolute top-1 h-6 w-6 rounded-full bg-white shadow transition-all ${
                profile.blockingEnabled ? "left-1" : "left-9"
              }`}
            />
          </button>
        </div>
        {!profile.blockingEnabled && (
          <p className="mt-3 rounded-lg bg-amber-50 px-3 py-2 text-sm text-amber-700">
            ⚠️ وضع الطوارئ مفعّل: الحظر معطّل والإنترنت سيبقى مفتوحًا حتى بعد
            تجاوز الحد.
          </p>
        )}
      </div>

      {/* الخطط */}
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        <div className="nw-card p-6">
          <h3 className="text-lg font-bold text-[var(--nw-pink-700)]">
            الخطة المجانية
          </h3>
          <p className="mt-1 text-2xl font-extrabold">مجانًا</p>
          <ul className="mt-4 space-y-2 text-sm">
            <li>✅ حساب الحد اليومي التلقائي</li>
            <li>✅ تنبيهات ذكية + حظر ساعة عند التجاوز</li>
            <li>✅ إلغاء الحظر في الطوارئ</li>
            <li>✅ تحليل تقديري لاستهلاك التطبيقات</li>
          </ul>
          {profile.plan === "paid" && (
            <button
              onClick={onDowngrade}
              disabled={busy}
              className="nw-btn mt-5 w-full rounded-xl border border-[var(--nw-pink-200)] bg-white py-2.5 text-sm font-semibold text-[var(--nw-pink-600)]"
            >
              الرجوع للخطة المجانية
            </button>
          )}
        </div>

        <div className="nw-card relative overflow-hidden p-6 ring-2 ring-[var(--nw-pink-300)]">
          <span className="absolute left-4 top-4 rounded-full bg-emerald-100 px-3 py-1 text-xs font-bold text-emerald-700">
            أول شهرين مجانًا 🎁
          </span>
          <h3 className="text-lg font-bold text-[var(--nw-pink-700)]">
            الخطة المدفوعة ✨
          </h3>
          <p className="mt-1 text-2xl font-extrabold">
            49 ج.م<span className="text-sm font-medium">/شهر</span>
          </p>
          <ul className="mt-4 space-y-2 text-sm">
            <li>⭐ كل مزايا الخطة المجانية</li>
            <li>🤖 تحليل دقيق لكل تطبيق عبر Gemini AI</li>
            <li>📊 توقّعات وتوصيات ترشيد متقدمة</li>
            <li>🔔 تنبيهات مخصّصة حسب سلوكك</li>
          </ul>
          {profile.plan === "paid" ? (
            <div className="nw-gradient-soft mt-5 rounded-xl py-2.5 text-center text-sm font-bold text-[var(--nw-pink-700)]">
              أنت مشترك حاليًا ✅
            </div>
          ) : (
            <button
              onClick={onUpgrade}
              disabled={busy}
              className="nw-btn nw-gradient mt-5 w-full rounded-xl py-2.5 text-sm font-bold text-white"
            >
              ابدأ شهرين مجانًا
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
