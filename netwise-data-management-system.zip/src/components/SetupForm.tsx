"use client";

import { useState } from "react";

export type SetupValues = {
  name: string;
  phone: string;
  monthlyGb: string;
  usedGb: string;
  remainingDays: string;
};

export default function SetupForm({
  onSubmit,
  loading,
  initial,
}: {
  onSubmit: (v: SetupValues) => void;
  loading: boolean;
  initial?: Partial<SetupValues>;
}) {
  const [values, setValues] = useState<SetupValues>({
    name: initial?.name ?? "",
    phone: initial?.phone ?? "",
    monthlyGb: initial?.monthlyGb ?? "",
    usedGb: initial?.usedGb ?? "",
    remainingDays: initial?.remainingDays ?? "",
  });
  const [error, setError] = useState("");

  const set = (k: keyof SetupValues, v: string) =>
    setValues((prev) => ({ ...prev, [k]: v }));

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!values.name.trim() || !values.phone.trim()) {
      setError("من فضلك أدخل الاسم ورقم التليفون.");
      return;
    }
    if (
      Number(values.monthlyGb) <= 0 ||
      Number(values.usedGb) < 0 ||
      Number(values.remainingDays) <= 0
    ) {
      setError("أدخل قيم الجيجا والأيام بشكل صحيح.");
      return;
    }
    if (Number(values.usedGb) > Number(values.monthlyGb)) {
      setError("المستهلك لا يمكن أن يتجاوز إجمالي الباقة.");
      return;
    }
    setError("");
    onSubmit(values);
  }

  return (
    <form onSubmit={handleSubmit} className="nw-card nw-pop p-6 sm:p-8">
      <h2 className="mb-1 text-xl font-bold text-[var(--nw-pink-700)]">
        بيانات العميل والباقة
      </h2>
      <p className="mb-6 text-sm text-[var(--nw-muted)]">
        أدخل بياناتك ليقوم NetWise بحساب حدك اليومي وتحليل استهلاك تطبيقاتك.
      </p>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <label className="block">
          <span className="mb-1 block text-sm font-semibold">الاسم</span>
          <input
            className="nw-input"
            value={values.name}
            onChange={(e) => set("name", e.target.value)}
            placeholder="مثال: منى أحمد"
          />
        </label>
        <label className="block">
          <span className="mb-1 block text-sm font-semibold">رقم التليفون</span>
          <input
            className="nw-input"
            value={values.phone}
            onChange={(e) => set("phone", e.target.value)}
            placeholder="01xxxxxxxxx"
            inputMode="tel"
          />
        </label>
        <label className="block">
          <span className="mb-1 block text-sm font-semibold">
            جيجا الباقة الشهرية
          </span>
          <input
            className="nw-input"
            type="number"
            min={0}
            step="0.1"
            value={values.monthlyGb}
            onChange={(e) => set("monthlyGb", e.target.value)}
            placeholder="مثال: 40"
          />
        </label>
        <label className="block">
          <span className="mb-1 block text-sm font-semibold">
            المستهلك حتى الآن (جيجا)
          </span>
          <input
            className="nw-input"
            type="number"
            min={0}
            step="0.1"
            value={values.usedGb}
            onChange={(e) => set("usedGb", e.target.value)}
            placeholder="مثال: 12"
          />
        </label>
        <label className="block sm:col-span-2">
          <span className="mb-1 block text-sm font-semibold">
            عدد الأيام الباقية في الشهر
          </span>
          <input
            className="nw-input"
            type="number"
            min={1}
            step="1"
            value={values.remainingDays}
            onChange={(e) => set("remainingDays", e.target.value)}
            placeholder="مثال: 18"
          />
        </label>
      </div>

      {error && (
        <p className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-600">
          {error}
        </p>
      )}

      <button
        type="submit"
        disabled={loading}
        className="nw-btn nw-gradient mt-6 w-full rounded-xl py-3 font-bold text-white shadow-lg disabled:opacity-60"
      >
        {loading ? "جارٍ التحليل بواسطة Gemini…" : "احسب حدّي اليومي وحلّل استهلاكي"}
      </button>
    </form>
  );
}
