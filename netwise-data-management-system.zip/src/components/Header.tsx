export default function Header() {
  return (
    <header className="mb-8 flex flex-col items-center gap-3 text-center sm:flex-row sm:justify-between sm:text-right">
      <div className="flex items-center gap-3">
        <div className="nw-gradient flex h-14 w-14 items-center justify-center rounded-2xl text-2xl shadow-lg">
          📶
        </div>
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight text-[var(--nw-pink-700)]">
            NetWise
          </h1>
          <p className="text-sm text-[var(--nw-muted)]">
            إدارة استهلاك الإنترنت بذكاء
          </p>
        </div>
      </div>
      <div className="rounded-full border border-[var(--nw-pink-200)] bg-white/70 px-4 py-2 text-xs font-semibold text-[var(--nw-pink-600)]">
        Created by Jana &amp; Sara
      </div>
    </header>
  );
}
